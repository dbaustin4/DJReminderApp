const accountSid = "AC06c5dd1b979075dd619890fcaf03ce81";
const authToken = "edd083adf346953c908510ba72e6c460";
const client = require('twilio')(accountSid, authToken);

client.messages
  .create({
     body: 'Check this out, gotta get back to work.',
     from: '+12566661974',
     to: '+31613637482'
   })
  .then(message => console.log(message.sid));